"""
IMU Fall Detection — Two-Phase Algorithm
═════════════════════════════════════════
Phase 1 — Free-fall : magnitude < 0.5 g  for ≥ 10 consecutive samples (100 ms @ 100 Hz)
Phase 2 — Impact    : magnitude > 3.0 g  within 50 samples (500 ms) after Phase 1 ends

Three test scenarios
  A  Genuine fall        → FALL DETECTED
  B  Hard vibration only → NO FALL
  C  Slow sit-down       → NO FALL
"""

import csv
from dataclasses import dataclass, field

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# ── Constants (exact values from the spec) ────────────────────────────────────
SAMPLE_RATE        = 100    # Hz
FREE_FALL_THRESH   = 0.5    # g
FREE_FALL_MIN_SAMP = 10     # samples (100 ms)
IMPACT_THRESH      = 3.0    # g
IMPACT_WINDOW      = 50     # samples (500 ms)

CSV_PATH  = "/mnt/user-data/outputs/imu_data.csv"
PLOT_PATH = "/mnt/user-data/outputs/imu_fall_detection.png"

DURATION      = 4           # seconds per scenario
N             = SAMPLE_RATE * DURATION


# ══════════════════════════════════════════════════════════════════════════════
#  DATA GENERATORS  — one function per scenario
# ══════════════════════════════════════════════════════════════════════════════

def _baseline(rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Gentle walking baseline (magnitude ≈ 1 g with small sinusoidal sway)."""
    t = np.linspace(0, DURATION, N)
    x = 0.10 * np.sin(2 * np.pi * 1.8 * t) + rng.normal(0, 0.04, N)
    y = 0.12 * np.sin(2 * np.pi * 1.8 * t + np.pi / 3) + rng.normal(0, 0.04, N)
    z = 1.00 + 0.07 * np.sin(2 * np.pi * 0.9 * t) + rng.normal(0, 0.04, N)
    return x, y, z


def scenario_a_genuine_fall(seed: int = 1) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Scenario A — Genuine fall
    ─────────────────────────
    t = 1.50 s : free-fall begins (all axes ≈ 0 g for ~150 ms / 15 samples)
    t = 1.65 s : impact spike (magnitude > 4 g for ~60 ms)
    """
    rng = np.random.default_rng(seed)
    t   = np.linspace(0, DURATION, N)
    x, y, z = _baseline(rng)

    ff_start = int(1.50 * SAMPLE_RATE)
    ff_end   = ff_start + 15                       # 150 ms free-fall
    imp_end  = ff_end   + 6                        # 60 ms impact

    # Free-fall: near-zero on all axes
    x[ff_start:ff_end] = rng.normal(0.05, 0.04, ff_end - ff_start)
    y[ff_start:ff_end] = rng.normal(0.05, 0.04, ff_end - ff_start)
    z[ff_start:ff_end] = rng.normal(0.05, 0.04, ff_end - ff_start)

    # Impact
    x[ff_end:imp_end]  = rng.normal( 2.3, 0.20, imp_end - ff_end)
    y[ff_end:imp_end]  = rng.normal(-1.5, 0.20, imp_end - ff_end)
    z[ff_end:imp_end]  = rng.normal( 3.8, 0.30, imp_end - ff_end)

    return t, x, y, z


def scenario_b_hard_vibration(seed: int = 2) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Scenario B — Hard vibration only (no free-fall)
    ─────────────────────────────────────────────────
    t = 1.80 s : sudden impact-sized spike (~4 g) with NO preceding low-g phase.
                 Magnitude never drops below 0.5 g before the spike.
    """
    rng = np.random.default_rng(seed)
    t   = np.linspace(0, DURATION, N)
    x, y, z = _baseline(rng)

    spike_s = int(1.80 * SAMPLE_RATE)
    spike_e = spike_s + 5                          # 50 ms spike

    x[spike_s:spike_e] = rng.normal( 2.1, 0.15, spike_e - spike_s)
    y[spike_s:spike_e] = rng.normal(-2.0, 0.15, spike_e - spike_s)
    z[spike_s:spike_e] = rng.normal( 3.5, 0.20, spike_e - spike_s)

    return t, x, y, z


def scenario_c_slow_sitdown(seed: int = 3) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Scenario C — Slow sit-down
    ──────────────────────────
    The person bends and sits: z gradually decreases, x/y shift slowly.
    Magnitude dips briefly toward 0.3–0.5 g for a prolonged period (> 500 ms),
    then settles at a new resting level — never producing an impact spike.
    """
    rng = np.random.default_rng(seed)
    t   = np.linspace(0, DURATION, N)
    x, y, z = _baseline(rng)

    sit_start = int(1.20 * SAMPLE_RATE)
    sit_end   = sit_start + 80              # 800 ms gradual motion

    # Smooth envelope: cosine ramp from 1 g down to 0.35 g and back to 0.9 g
    envelope = 1.0 - 0.65 * np.sin(np.linspace(0, np.pi, sit_end - sit_start))
    z[sit_start:sit_end] = envelope + rng.normal(0, 0.04, sit_end - sit_start)
    x[sit_start:sit_end] = 0.08 * np.linspace(0, 1, sit_end - sit_start) \
                           + rng.normal(0, 0.04, sit_end - sit_start)
    y[sit_start:sit_end] = rng.normal(0, 0.04, sit_end - sit_start)

    return t, x, y, z


# ══════════════════════════════════════════════════════════════════════════════
#  TWO-PHASE DETECTOR
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class DetectionResult:
    verdict:         str            # "FALL DETECTED" | "NO FALL"
    reason:          str
    freefall_mask:   np.ndarray
    impact_mask:     np.ndarray
    confirmed_mask:  np.ndarray
    ff_start_idx:    int  = -1
    ff_end_idx:      int  = -1
    impact_idx:      int  = -1
    impact_mag:      float = 0.0


def two_phase_detect(
    x: np.ndarray,
    y: np.ndarray,
    z: np.ndarray,
) -> DetectionResult:
    """
    Two-phase fall detector.

    Phase 1  Scan for a run of ≥ FREE_FALL_MIN_SAMP consecutive samples
             where magnitude < FREE_FALL_THRESH.

    Phase 2  Once a valid free-fall window is found, look at the next
             IMPACT_WINDOW samples for any magnitude > IMPACT_THRESH.
             Both conditions must be met to confirm a fall.
    """
    n   = len(x)
    mag = np.sqrt(x**2 + y**2 + z**2)

    freefall_mask  = np.zeros(n, dtype=bool)
    impact_mask    = mag > IMPACT_THRESH
    confirmed_mask = np.zeros(n, dtype=bool)

    i = 0
    while i < n:

        # ── Phase 1: hunt for free-fall onset ─────────────────────────────────
        if mag[i] >= FREE_FALL_THRESH:
            i += 1
            continue

        ff_start = i
        while i < n and mag[i] < FREE_FALL_THRESH:
            i += 1
        ff_end = i                          # first sample back above threshold
        ff_len = ff_end - ff_start

        if ff_len < FREE_FALL_MIN_SAMP:
            # Too brief — sensor noise, not weightlessness
            continue

        # Valid free-fall window found
        freefall_mask[ff_start:ff_end] = True

        # ── Phase 2: confirm impact ────────────────────────────────────────────
        win_end    = min(ff_end + IMPACT_WINDOW, n)
        window_mag = mag[ff_end:win_end]

        if window_mag.size == 0 or window_mag.max() <= IMPACT_THRESH:
            # Free-fall with no impact — slow sit-down or device placed gently
            return DetectionResult(
                verdict        = "NO FALL",
                reason         = (
                    f"Free-fall detected ({ff_len} samples) but no impact spike "
                    f"> {IMPACT_THRESH} g within {IMPACT_WINDOW} samples after it ended"
                ),
                freefall_mask  = freefall_mask,
                impact_mask    = impact_mask,
                confirmed_mask = confirmed_mask,
                ff_start_idx   = ff_start,
                ff_end_idx     = ff_end,
            )

        peak_off = int(np.argmax(window_mag))
        peak_idx = ff_end + peak_off
        peak_mag = float(window_mag[peak_off])

        confirmed_mask[ff_start : peak_idx + 1] = True

        return DetectionResult(
            verdict        = "FALL DETECTED",
            reason         = (
                f"Phase 1 — free-fall: {ff_len} consecutive samples < {FREE_FALL_THRESH} g  |  "
                f"Phase 2 — impact: {peak_mag:.2f} g at sample {peak_idx} "
                f"({peak_off} samples / {peak_off*10:.0f} ms after free-fall ended)"
            ),
            freefall_mask  = freefall_mask,
            impact_mask    = impact_mask,
            confirmed_mask = confirmed_mask,
            ff_start_idx   = ff_start,
            ff_end_idx     = ff_end,
            impact_idx     = peak_idx,
            impact_mag     = peak_mag,
        )

    # Reached end of data without finding a qualifying free-fall
    return DetectionResult(
        verdict        = "NO FALL",
        reason         = (
            f"No run of ≥ {FREE_FALL_MIN_SAMP} consecutive samples "
            f"below {FREE_FALL_THRESH} g found"
        ),
        freefall_mask  = freefall_mask,
        impact_mask    = impact_mask,
        confirmed_mask = confirmed_mask,
    )


# ══════════════════════════════════════════════════════════════════════════════
#  TERMINAL OUTPUT
# ══════════════════════════════════════════════════════════════════════════════

_SEP = "─" * 62

def print_scenario(
    label: str,
    description: str,
    timestamps: np.ndarray,
    result: DetectionResult,
) -> None:
    verdict_icon = "⚠ " if result.verdict == "FALL DETECTED" else "✔ "
    verdict_col  = "\033[91m" if result.verdict == "FALL DETECTED" else "\033[92m"
    reset        = "\033[0m"

    print(_SEP)
    print(f"  {label}  {description}")
    print(_SEP)
    print(f"  {verdict_col}{verdict_icon}{result.verdict}{reset}")
    print(f"  Reason : {result.reason}")

    if result.verdict == "FALL DETECTED":
        ff_t = timestamps[result.ff_start_idx]
        imp_t = timestamps[result.impact_idx]
        print(f"  Free-fall onset : {ff_t:.3f} s")
        print(f"  Impact peak     : {imp_t:.3f} s  ({result.impact_mag:.2f} g)")
        print(f"  Total latency   : {(imp_t - ff_t)*1000:.0f} ms")
    print()


# ══════════════════════════════════════════════════════════════════════════════
#  CSV  — one file, three scenario blocks
# ══════════════════════════════════════════════════════════════════════════════

def save_csv(
    path: str,
    scenarios: list[tuple[str, np.ndarray, np.ndarray, np.ndarray,
                          np.ndarray, DetectionResult]],
) -> None:
    with open(path, "w", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow([
            "scenario", "timestamp", "x", "y", "z", "magnitude",
            "freefall_phase", "impact_phase", "fall_detected",
        ])
        for label, t, x, y, z, res in scenarios:
            mag = np.sqrt(x**2 + y**2 + z**2)
            for row in zip(t, x, y, z, mag,
                           res.freefall_mask, res.impact_mask, res.confirmed_mask):
                ts, xi, yi, zi, mi, ff, imp, conf = row
                writer.writerow([
                    label,
                    f"{ts:.3f}", f"{xi:.4f}", f"{yi:.4f}",
                    f"{zi:.4f}", f"{mi:.4f}",
                    int(ff), int(imp), int(conf),
                ])
    print(f"  ✔  CSV saved → {path}")


# ══════════════════════════════════════════════════════════════════════════════
#  PLOT — three stacked magnitude panels, one per scenario
# ══════════════════════════════════════════════════════════════════════════════

def _shade(ax, timestamps, mask, colour, alpha):
    if not np.any(mask):
        return
    idx  = np.where(mask)[0]
    gaps = np.where(np.diff(idx) > 1)[0] + 1
    for grp in np.split(idx, gaps):
        ax.axvspan(timestamps[grp[0]], timestamps[grp[-1]],
                   color=colour, alpha=alpha, zorder=2)


def plot_scenarios(
    path: str,
    scenarios: list[tuple[str, np.ndarray, np.ndarray,
                          np.ndarray, np.ndarray, DetectionResult]],
) -> None:
    BG_DARK  = "#0f1117"
    BG_PANEL = "#1a1d27"
    GRID_COL = "#2e3247"

    fig, axes = plt.subplots(3, 1, figsize=(14, 10), sharex=False)
    fig.patch.set_facecolor(BG_DARK)

    panel_colours = ["#4fc3f7", "#81c784", "#ffb74d"]

    for ax, colour, (label, t, x, y, z, res) in zip(axes, panel_colours, scenarios):
        mag = np.sqrt(x**2 + y**2 + z**2)

        ax.set_facecolor(BG_PANEL)
        ax.plot(t, mag, color=colour, linewidth=0.9, alpha=0.92, zorder=3,
                label="Magnitude (g)")

        # Phase shading
        _shade(ax, t, res.freefall_mask,  "#ffb300", 0.30)   # amber  — free-fall
        _shade(ax, t, res.impact_mask,    "#ff5252", 0.22)   # red    — raw spikes
        _shade(ax, t, res.confirmed_mask, "#00e676", 0.18)   # green  — confirmed fall

        # Threshold lines
        ax.axhline(IMPACT_THRESH,   color="#ff5252", linewidth=0.9,
                   linestyle="--", alpha=0.80, zorder=4)
        ax.axhline(FREE_FALL_THRESH, color="#ffb300", linewidth=0.9,
                   linestyle="--", alpha=0.80, zorder=4)

        # Verdict badge
        is_fall = res.verdict == "FALL DETECTED"
        badge_col = "#00e676" if is_fall else "#aaaaaa"
        badge_txt = f"{'⚠  ' if is_fall else '✔  '}{res.verdict}"
        ax.text(0.99, 0.93, badge_txt,
                transform=ax.transAxes, ha="right", va="top",
                color=badge_col, fontsize=9, fontweight="bold",
                bbox=dict(boxstyle="round,pad=0.3", fc=BG_DARK, ec=badge_col,
                          linewidth=0.8, alpha=0.90))

        # Phase boundary markers for confirmed falls
        if is_fall and res.ff_start_idx >= 0:
            for t_v, col, lbl in [
                (t[res.ff_start_idx], "#ffb300", "FF↓"),
                (t[res.ff_end_idx - 1],   "#ffb300", "FF↑"),
                (t[res.impact_idx],   "#ff5252", "Impact"),
            ]:
                ax.axvline(t_v, color=col, linewidth=1.0,
                           linestyle=":", alpha=0.95, zorder=5)
                ax.text(t_v + 0.02, ax.get_ylim()[1] * 0.96,
                        lbl, color=col, fontsize=7, va="top")

        ax.set_ylabel("Magnitude (g)", color="white", fontsize=9)
        ax.set_title(f"{label}", color="white", fontsize=10,
                     fontweight="bold", loc="left", pad=4)
        ax.tick_params(colors="white", labelsize=8)
        for spine in ax.spines.values():
            spine.set_edgecolor("#444")
        ax.grid(True, color=GRID_COL, linewidth=0.45, linestyle=":")
        ax.set_xlim(t[0], t[-1])

    axes[-1].set_xlabel("Time (s)", color="white", fontsize=10)
    axes[-1].tick_params(axis="x", colors="white")

    legend_items = [
        mpatches.Patch(color="#ffb300", alpha=0.60,
                       label=f"Free-fall phase (< {FREE_FALL_THRESH} g)"),
        mpatches.Patch(color="#ff5252", alpha=0.55,
                       label=f"Impact spike (> {IMPACT_THRESH} g)"),
        mpatches.Patch(color="#00e676", alpha=0.45,
                       label="Confirmed fall (both phases)"),
    ]
    fig.legend(handles=legend_items, loc="upper center", ncol=3,
               facecolor=BG_PANEL, labelcolor="white", fontsize=8.5,
               bbox_to_anchor=(0.5, 1.01), framealpha=0.9)

    fig.suptitle(
        "Two-Phase Fall Detection — Three Scenarios\n"
        f"Phase 1: < {FREE_FALL_THRESH} g for ≥ {FREE_FALL_MIN_SAMP} samples   │   "
        f"Phase 2: > {IMPACT_THRESH} g within {IMPACT_WINDOW} samples",
        color="white", fontsize=11, fontweight="bold", y=1.06,
    )

    plt.tight_layout(h_pad=2.2)
    plt.savefig(path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close()
    print(f"  ✔  Plot saved → {path}")


# ══════════════════════════════════════════════════════════════════════════════
#  EXPLANATION
# ══════════════════════════════════════════════════════════════════════════════

EXPLANATION = """
Why two-phase detection reduces false alarms
═════════════════════════════════════════════
1. A single threshold fires on ANY large spike — a dropped phone, a table knock,
   or a car door slam all produce impacts > 3 g without a person falling.

2. Real falls have a biomechanical signature: the body briefly enters near-
   weightlessness (free-fall) BEFORE hitting the ground. Requiring Phase 1
   first eliminates every spike that lacks this precursor.

3. The minimum free-fall duration (10 samples / 100 ms) rejects transient sensor
   noise that momentarily dips below 0.5 g — noise hits are typically 1–3 samples.

4. Phase 2's 500 ms confirmation window is tight enough to link the impact to the
   specific free-fall that caused it, preventing a delayed unrelated spike from
   triggering a false alarm.

5. Slow postural changes (sitting, bending) may produce a prolonged low-g phase
   but never generate a high-g impact spike, so Phase 2 fails and no alarm fires.
"""


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("\n" + "═" * 62)
    print("  IMU Fall Detection — Two-Phase Algorithm")
    print("═" * 62 + "\n")

    # ── Generate data ──────────────────────────────────────────────────────────
    tA, xA, yA, zA = scenario_a_genuine_fall()
    tB, xB, yB, zB = scenario_b_hard_vibration()
    tC, xC, yC, zC = scenario_c_slow_sitdown()

    # ── Run detector on each scenario ──────────────────────────────────────────
    resA = two_phase_detect(xA, yA, zA)
    resB = two_phase_detect(xB, yB, zB)
    resC = two_phase_detect(xC, yC, zC)

    # ── Print verdicts ─────────────────────────────────────────────────────────
    print_scenario("Scenario A", "Genuine fall (free-fall + impact)",        tA, resA)
    print_scenario("Scenario B", "Hard vibration only (spike, no free-fall)",tB, resB)
    print_scenario("Scenario C", "Slow sit-down (gradual motion, no impact)",tC, resC)
    print(_SEP + "\n")

    # ── CSV ────────────────────────────────────────────────────────────────────
    all_scenarios = [
        ("A – Genuine fall",    tA, xA, yA, zA, resA),
        ("B – Hard vibration",  tB, xB, yB, zB, resB),
        ("C – Slow sit-down",   tC, xC, yC, zC, resC),
    ]
    save_csv(CSV_PATH, all_scenarios)

    # ── Plot ───────────────────────────────────────────────────────────────────
    plot_scenarios(PLOT_PATH, all_scenarios)

    # ── Explanation ────────────────────────────────────────────────────────────
    print(EXPLANATION)
