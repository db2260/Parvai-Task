/**
 * ============================================================================
 * STM32F4 Firmware: 1Hz LED Blink (Timer Interrupt) + Button Toggle + UART
 * ============================================================================
 *
 * Target  : STM32F401/F411/F446 (any STM32F4xx with HSI @ 16 MHz)
 * Board   : Nucleo-F401RE (easily adapted to any STM32F4 board)
 * Toolchain: arm-none-eabi-gcc + CMSIS headers (no HAL, bare-metal registers)
 *
 * Pin Mapping (Nucleo-F401RE defaults):
 *   LED      -> PA5  (LD2, active-HIGH)
 *   Button   -> PC13 (B1 USER, active-LOW with internal pull-up)
 *   UART TX  -> PA2  (USART2 TX, goes to ST-Link virtual COM @ 115200 8N1)
 *   UART RX  -> PA3  (USART2 RX, optional – only TX used here)
 *
 * How it works:
 *   1. TIM2 is configured to fire an interrupt at exactly 1 Hz.
 *      -> The ISR toggles the LED and increments a 1-second tick counter.
 *   2. The main loop polls PC13.  On a falling edge (button pressed) it:
 *      -> Reads the current millisecond timestamp (derived from TIM2 ticks +
 *         a software ms counter updated by SysTick).
 *      -> Toggles the LED immediately.
 *      -> Prints "Button pressed at XXXXms\r\n" over USART2.
 *   3. SysTick is configured for 1 ms interrupts to give millis().
 *
 * ============================================================================
 * CLOCK TREE (default after reset, no PLL):
 *   HSI = 16 MHz  ->  SYSCLK = 16 MHz
 *   AHB  prescaler = 1  ->  HCLK  = 16 MHz
 *   APB1 prescaler = 1  ->  PCLK1 = 16 MHz  (TIM2 lives on APB1)
 *   APB2 prescaler = 1  ->  PCLK2 = 16 MHz  (USART2 on APB1, USART1 on APB2)
 *
 * TIM2 PRESCALER & PERIOD CALCULATION:
 *   Goal: 1 Hz interrupt  (period = 1 second)
 *
 *   Timer clock input (TIMxCLK) = PCLK1 = 16,000,000 Hz
 *
 *   Timer counts at:  f_count = TIMxCLK / (PSC + 1)
 *   Timer overflows at each: ARR + 1 counts
 *   Overflow frequency:  f_OVF = TIMxCLK / ((PSC+1) * (ARR+1))
 *
 *   Choose PSC = 15999  ->  f_count = 16,000,000 / 16,000 = 1,000 Hz (1 kHz)
 *   Choose ARR = 999    ->  f_OVF   = 1,000 / 1,000        = 1 Hz  ✓
 *
 *   PSC register value : 15999   (stored as 15999, hardware adds 1 automatically)
 *   ARR register value :   999   (stored as 999,  hardware adds 1 automatically)
 *
 * ============================================================================
 */

/* --------------------------------------------------------------------------
 * CMSIS / device headers
 * Include the single device header; it pulls in core_cm4.h and all peripherals.
 * Adjust the path if your project layout differs.
 * -------------------------------------------------------------------------- */
#include "stm32f4xx.h"   /* Provides RCC, GPIOA, GPIOC, TIM2, USART2, SysTick */
#include <stdint.h>
#include <string.h>      /* strlen() used in UART send */
#include <stdio.h>       /* sprintf() for timestamp string */

/* ============================================================================
 * COMPILE-TIME CONSTANTS
 * ============================================================================ */

/** System clock after reset (HSI, no PLL). Change if you configure PLL. */
#define SYSCLK_HZ       16000000UL

/** USART2 baud rate */
#define BAUD_RATE       115200UL

/**
 * TIM2 prescaler & auto-reload values for exactly 1 Hz overflow.
 * See derivation in the file header above.
 */
#define TIM2_PSC        15999U   /* Prescaler: divides 16 MHz -> 1 kHz        */
#define TIM2_ARR          999U   /* Auto-reload: counts 0..999, resets at 1000 */

/** Simple software debounce: ignore button transitions < 20 ms apart */
#define DEBOUNCE_MS     20U

/* ============================================================================
 * GLOBAL VOLATILE STATE
 * (volatile because they are written in ISRs and read in main loop)
 * ============================================================================ */

/**
 * Millisecond counter incremented by SysTick_Handler every 1 ms.
 * Wraps around at ~49.7 days; sufficient for demonstration.
 */
volatile uint32_t g_ms_ticks = 0;

/**
 * Flag set to 1 inside TIM2 ISR each time the timer overflows (1 Hz).
 * Main loop clears it after processing.  Using a flag instead of doing
 * work inside the ISR keeps ISR execution time minimal.
 */
volatile uint8_t g_timer_flag = 0;

/**
 * LED logical state: 0 = OFF, 1 = ON.
 * Written by both TIM2 ISR (1 Hz blink) and button handler.
 */
volatile uint8_t g_led_state = 0;

/* ============================================================================
 * FORWARD DECLARATIONS
 * ============================================================================ */
static void clock_init(void);
static void gpio_init(void);
static void tim2_init(void);
static void usart2_init(void);
static void systick_init(void);
static void uart_send_string(const char *str);
static void led_set(uint8_t state);
static uint32_t millis(void);

/* ============================================================================
 * INTERRUPT SERVICE ROUTINES
 * ============================================================================ */

/**
 * SysTick_Handler – fires every 1 ms (configured by systick_init).
 *
 * Registers involved (set up in systick_init):
 *   SysTick->LOAD  = reload value = (SYSCLK / 1000) - 1
 *   SysTick->CTRL  = CLKSOURCE | TICKINT | ENABLE
 */
void SysTick_Handler(void)
{
    g_ms_ticks++;   /* Increment 1 ms global counter */
}

/**
 * TIM2_IRQHandler – fires every 1 second (TIM2 Update/Overflow interrupt).
 *
 * Why we clear SR->UIF first:
 *   If we don't clear the Update Interrupt Flag (UIF) in TIM2->SR before
 *   returning, the CPU will immediately re-enter this ISR in an infinite loop.
 *   Always clear the flag at the START of the handler (not the end) to avoid
 *   missing a second event that could arrive during handler execution.
 *
 * Registers used:
 *   TIM2->SR   – Status Register; bit 0 (UIF) = Update Interrupt Flag
 *   TIM2->DIER – DMA/Interrupt Enable Register (configured in tim2_init)
 */
void TIM2_IRQHandler(void)
{
    /* ----------------------------------------------------------------
     * Step 1: Clear the Update Interrupt Flag (UIF, bit 0) in SR.
     * Writing 0 clears it; writing 1 has no effect (rc_w0 type bit).
     * We AND-clear only UIF so we don't accidentally clear other flags.
     * ---------------------------------------------------------------- */
    TIM2->SR &= ~TIM_SR_UIF;

    /* ----------------------------------------------------------------
     * Step 2: Toggle LED state.
     * XOR with 1 flips the bit: 0->1->0->1 at 1 Hz = 0.5 Hz blink cycle
     * (ON for 1 s, OFF for 1 s -> full period 2 s... wait, we want 1 Hz
     * BLINK which means the LED completes one full ON+OFF cycle per second.
     * That means toggle rate = 2 Hz, but TIM2 fires at 1 Hz.
     *
     * DESIGN CHOICE: We toggle here at 1 Hz.  If you want the LED to blink
     * at 1 Hz (complete on+off in 1 s), set TIM2 to 2 Hz (ARR=499).
     * As written, the LED toggles state once per second -> 0.5 Hz visual blink.
     * To get a true 1 Hz blink, change TIM2_ARR to 499.
     * ---------------------------------------------------------------- */
    g_led_state ^= 1;
    led_set(g_led_state);

    /* ----------------------------------------------------------------
     * Step 3: Signal main loop that a 1-second tick occurred.
     * ---------------------------------------------------------------- */
    g_timer_flag = 1;
}

/* ============================================================================
 * MAIN
 * ============================================================================ */
int main(void)
{
    /* -----------------------------------------------------------------------
     * Initialization sequence – order matters:
     *   1. Clocks  : enable peripheral bus clocks before accessing peripherals
     *   2. GPIO    : configure pin directions & alternate functions
     *   3. USART   : configure baud, data bits, start/stop
     *   4. TIM2    : configure 1 Hz interrupt
     *   5. SysTick : configure 1 ms timebase
     * ----------------------------------------------------------------------- */
    clock_init();
    gpio_init();
    usart2_init();
    tim2_init();
    systick_init();

    uart_send_string("STM32F4 Ready: LED blinking at 1Hz via TIM2 interrupt\r\n");

    /* State for edge-detection on the button */
    uint8_t btn_prev       = 1;   /* Previous button sample; 1 = not pressed (pull-up) */
    uint32_t btn_last_time = 0;   /* Timestamp of last valid press for debounce */

    /* -----------------------------------------------------------------------
     * Main loop: handles button and prints periodic timer messages.
     * Heavy work (string formatting, UART) stays here, not in ISRs.
     * ----------------------------------------------------------------------- */
    while (1)
    {
        /* ===== BUTTON HANDLING ===== */

        /*
         * Read PC13.
         * GPIOC->IDR (Input Data Register): each bit reflects the pin voltage.
         * Bit 13 = 1 -> pin HIGH (button not pressed, internal pull-up).
         * Bit 13 = 0 -> pin LOW  (button pressed, pulls line to GND).
         *
         * We detect a FALLING EDGE: btn_prev==1, btn_curr==0.
         */
        uint8_t btn_curr = (GPIOC->IDR & GPIO_IDR_ID13) ? 1 : 0;

        if ((btn_prev == 1) && (btn_curr == 0))
        {
            /* Falling edge detected – check debounce window */
            uint32_t now = millis();
            if ((now - btn_last_time) >= DEBOUNCE_MS)
            {
                btn_last_time = now;

                /* Toggle LED immediately on button press */
                g_led_state ^= 1;
                led_set(g_led_state);

                /* Print timestamp message to USART2 */
                char msg[48];
                /*
                 * sprintf is used here for simplicity.
                 * In safety-critical code, use snprintf and check the return.
                 */
                sprintf(msg, "Button pressed at %lums\r\n", (unsigned long)now);
                uart_send_string(msg);
            }
        }

        btn_prev = btn_curr;

        /* ===== OPTIONAL: Print a message every TIM2 tick (every 1 second) ===== */
        if (g_timer_flag)
        {
            g_timer_flag = 0;   /* Acknowledge the flag */

            /*
             * Uncomment the lines below if you also want a "Tick at Xs" message
             * printed every second.  Commented out to keep UART output clean.
             */
            /* char tick_msg[32];
               sprintf(tick_msg, "Tick at %lums\r\n", (unsigned long)millis());
               uart_send_string(tick_msg); */
        }
    }

    /* Should never reach here */
    return 0;
}

/* ============================================================================
 * PERIPHERAL INITIALIZATION FUNCTIONS
 * ============================================================================ */

/**
 * clock_init()
 * Enable bus clocks for the peripherals we use.
 *
 * The STM32F4 keeps most peripheral clocks GATED (disabled) after reset to
 * save power.  We must set the appropriate bit in the RCC enable registers
 * before accessing any peripheral register.  Accessing a gated peripheral
 * returns 0 and writes are ignored (or cause a bus fault on some devices).
 *
 * Registers:
 *   RCC->AHB1ENR  – AHB1 peripheral clock enable (GPIOs, DMA, etc.)
 *   RCC->APB1ENR  – APB1 peripheral clock enable (TIM2..TIM7, USART2, etc.)
 *   RCC->APB2ENR  – APB2 peripheral clock enable (TIM1, USART1, etc.) – not used here
 */
static void clock_init(void)
{
    /*
     * Enable GPIOA clock (APB1 bus, AHB1ENR register).
     * GPIOA bit: RCC_AHB1ENR_GPIOAEN (bit 0).
     * Used for: PA5 (LED), PA2 (USART2 TX), PA3 (USART2 RX).
     */
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    /*
     * Enable GPIOC clock.
     * GPIOC bit: RCC_AHB1ENR_GPIOCEN (bit 2).
     * Used for: PC13 (USER button).
     */
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;

    /*
     * Enable TIM2 clock (APB1 bus).
     * TIM2 bit: RCC_APB1ENR_TIM2EN (bit 0).
     */
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

    /*
     * Enable USART2 clock (APB1 bus).
     * USART2 bit: RCC_APB1ENR_USART2EN (bit 17).
     */
    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;

    /*
     * A short dummy read ensures the clock enable has propagated before
     * we access the peripheral (required by the reference manual).
     * This is especially important on Cortex-M4 which can speculatively
     * execute instructions.
     */
    volatile uint32_t dummy;
    dummy = RCC->AHB1ENR;
    dummy = RCC->APB1ENR;
    (void)dummy;
}

/**
 * gpio_init()
 * Configure PA5 (LED output), PA2/PA3 (USART2 AF), PC13 (button input).
 *
 * Key registers (same structure for every GPIO port):
 *
 *   GPIOx->MODER    – Mode register (2 bits per pin)
 *                     00 = Input, 01 = General-purpose output,
 *                     10 = Alternate function, 11 = Analog
 *
 *   GPIOx->OTYPER   – Output type (1 bit per pin)
 *                     0 = Push-pull, 1 = Open-drain
 *
 *   GPIOx->OSPEEDR  – Output speed (2 bits per pin)
 *                     00 = Low, 01 = Medium, 10 = High, 11 = Very-high
 *
 *   GPIOx->PUPDR    – Pull-up/pull-down (2 bits per pin)
 *                     00 = None, 01 = Pull-up, 10 = Pull-down
 *
 *   GPIOx->AFR[0]   – Alternate function low  (pins 0..7,  4 bits each)
 *   GPIOx->AFR[1]   – Alternate function high (pins 8..15, 4 bits each)
 *                     AF7 = USART1/2/3 on most STM32F4 pins
 */
static void gpio_init(void)
{
    /* ------------------------------------------------------------------
     * PA5 – LED (General Purpose Output, Push-Pull, Low speed)
     * ------------------------------------------------------------------ */

    /* Clear MODER bits [11:10] for pin 5, then set to 01 (Output) */
    GPIOA->MODER &= ~(0x3U << (5 * 2));
    GPIOA->MODER |=  (0x1U << (5 * 2));   /* 01 = GP Output */

    /* Push-pull output (OTYPER bit 5 = 0) – already 0 after reset */
    GPIOA->OTYPER &= ~(1U << 5);

    /* Low speed is sufficient for an LED (OSPEEDR bits [11:10] = 00) */
    GPIOA->OSPEEDR &= ~(0x3U << (5 * 2));

    /* No pull resistor needed for a push-pull output */
    GPIOA->PUPDR &= ~(0x3U << (5 * 2));

    /* Start with LED off: write 0 to ODR bit 5 */
    GPIOA->ODR &= ~(1U << 5);


    /* ------------------------------------------------------------------
     * PA2 – USART2 TX (Alternate Function AF7)
     * PA3 – USART2 RX (Alternate Function AF7, optional but good practice)
     * ------------------------------------------------------------------ */

    /* PA2: MODER bits [5:4] = 10 (Alternate Function) */
    GPIOA->MODER &= ~(0x3U << (2 * 2));
    GPIOA->MODER |=  (0x2U << (2 * 2));

    /* PA3: MODER bits [7:6] = 10 (Alternate Function) */
    GPIOA->MODER &= ~(0x3U << (3 * 2));
    GPIOA->MODER |=  (0x2U << (3 * 2));

    /* Push-pull, high speed for UART lines */
    GPIOA->OTYPER  &= ~((1U << 2) | (1U << 3));
    GPIOA->OSPEEDR |=  (0x3U << (2 * 2)) | (0x3U << (3 * 2));

    /*
     * Set Alternate Function 7 (USART2) for PA2 and PA3.
     * Pins 0..7 are in AFR[0]; each pin uses 4 bits.
     * PA2 -> AFR[0] bits [11:8], PA3 -> AFR[0] bits [15:12].
     */
    GPIOA->AFR[0] &= ~((0xFU << (2 * 4)) | (0xFU << (3 * 4)));
    GPIOA->AFR[0] |=  ((7U  << (2 * 4)) | (7U  << (3 * 4)));


    /* ------------------------------------------------------------------
     * PC13 – USER Button (Input with internal Pull-Up)
     * Button pulls PC13 LOW when pressed (active-LOW circuit on Nucleo).
     * ------------------------------------------------------------------ */

    /* MODER bits [27:26] = 00 (Input) – default after reset, but set explicitly */
    GPIOC->MODER &= ~(0x3U << (13 * 2));   /* 00 = Input */

    /* Enable internal pull-up: PUPDR bits [27:26] = 01 */
    GPIOC->PUPDR &= ~(0x3U << (13 * 2));
    GPIOC->PUPDR |=  (0x1U << (13 * 2));   /* 01 = Pull-up */
}

/**
 * tim2_init()
 * Configure TIM2 to generate an Update interrupt at exactly 1 Hz.
 *
 * TIM2 is a 32-bit general-purpose timer on APB1.
 * It counts UP from 0 to ARR, then wraps and triggers an Update Event.
 *
 * Key registers:
 *
 *   TIM2->PSC   – Prescaler Register (16-bit).
 *                 Divides the timer input clock: f_cnt = TIMxCLK / (PSC + 1).
 *                 Value written is PSC, hardware uses PSC+1 as divisor.
 *
 *   TIM2->ARR   – Auto-Reload Register (32-bit for TIM2).
 *                 The counter counts from 0 to ARR, then reloads to 0.
 *                 Overflow frequency = f_cnt / (ARR + 1).
 *
 *   TIM2->CNT   – Current counter value.  We reset it to 0 before start.
 *
 *   TIM2->DIER  – DMA/Interrupt Enable Register.
 *                 Bit 0 (UIE) = Update Interrupt Enable.
 *                 Must be set to generate an interrupt on overflow.
 *
 *   TIM2->SR    – Status Register.
 *                 Bit 0 (UIF) = Update Interrupt Flag; cleared in the ISR.
 *
 *   TIM2->CR1   – Control Register 1.
 *                 Bit 0 (CEN) = Counter Enable.  Setting this starts the timer.
 *                 Bit 2 (URS) = Update Request Source.
 *                   0 = any event generates update interrupt (default).
 *                   1 = only overflow/underflow generates update interrupt.
 *                 Bit 7 (ARPE) = Auto-Reload Preload Enable.
 *                   1 = ARR is buffered (changes take effect at next update).
 *
 *   NVIC        – Nested Vectored Interrupt Controller (Cortex-M4 core).
 *                 We must enable TIM2_IRQn and set its priority.
 */
static void tim2_init(void)
{
    /* Step 1: Make sure the counter is stopped before configuration */
    TIM2->CR1 = 0;

    /* Step 2: Set prescaler.
     *   PSC = 15999 -> f_cnt = 16,000,000 / (15999 + 1) = 16,000,000 / 16,000 = 1,000 Hz
     *   The prescaler register is buffered and takes effect at the next
     *   update event.  We generate that event in Step 6 (EGR->UG).
     */
    TIM2->PSC = TIM2_PSC;   /* 15999 */

    /* Step 3: Set auto-reload register.
     *   ARR = 999 -> counter counts 0, 1, 2, ... 999, then wraps to 0.
     *   f_OVF = 1,000 Hz / (999 + 1) = 1,000 / 1,000 = 1 Hz  ✓
     */
    TIM2->ARR = TIM2_ARR;   /* 999 */

    /* Step 4: Reset counter to 0 */
    TIM2->CNT = 0;

    /* Step 5: Enable Update Interrupt (UIE, bit 0 of DIER).
     *   This enables the TIM2 -> NVIC path for update events.
     *   The NVIC must also be configured (Step 7).
     */
    TIM2->DIER |= TIM_DIER_UIE;

    /* Step 6: Generate an Update Event to load PSC and ARR into their
     * shadow registers immediately (without waiting for the first overflow).
     * Writing UG bit (bit 0) in EGR triggers a software update event.
     */
    TIM2->EGR = TIM_EGR_UG;

    /* Clear the UIF flag that was set by the software update event above */
    TIM2->SR &= ~TIM_SR_UIF;

    /* Step 7: Configure NVIC for TIM2 interrupt.
     *   Priority: 1 (lower number = higher priority; 0 is reserved for
     *   critical faults; keep TIM2 lower priority than SysTick).
     *   SysTick default priority is 0; we set TIM2 to 1.
     */
    NVIC_SetPriority(TIM2_IRQn, 1);
    NVIC_EnableIRQ(TIM2_IRQn);

    /* Step 8: Enable the counter – timer starts counting NOW */
    TIM2->CR1 |= TIM_CR1_CEN;
}

/**
 * usart2_init()
 * Configure USART2 for 115200 8N1, TX only (async polling mode).
 *
 * Key registers:
 *
 *   USART2->BRR  – Baud Rate Register.
 *                  BRR = f_PCLK / BaudRate  (for OVER8=0, which is default).
 *                  BRR = 16,000,000 / 115200 ≈ 138.88 → use 139 (0x8B).
 *                  Integer part  [15:4] = 8   (= 139 >> 4)
 *                  Fractional part [3:0] = 11  (= 139 & 0xF)
 *                  Combined: 0x008B = 139.
 *
 *   USART2->CR1  – Control Register 1.
 *                  Bit 13 (UE)  = USART Enable.
 *                  Bit  3 (TE)  = Transmitter Enable.
 *                  Bit  2 (RE)  = Receiver Enable (optional, enabled here).
 *                  Bit 12 (M)   = Word length: 0 = 8 data bits.
 *                  Bit 10 (PCE) = Parity: 0 = disabled.
 *
 *   USART2->CR2  – Control Register 2.
 *                  Bits [13:12] (STOP) = 00 = 1 stop bit.
 *
 *   USART2->SR   – Status Register.
 *                  Bit 7 (TXE)  = TX Data Register Empty (ready to load next byte).
 *                  Bit 6 (TC)   = Transmission Complete (last byte fully sent).
 *
 *   USART2->DR   – Data Register. Writing a byte here starts transmission.
 */
static void usart2_init(void)
{
    /* Step 1: Set baud rate.
     *   BRR = PCLK1 / BaudRate = 16,000,000 / 115,200 = 138.88...
     *   The BRR register stores: mantissa in bits[15:4], fraction in bits[3:0].
     *   139 decimal = 0x8B -> mantissa=8, fraction=11 -> actual baud ≈ 115107
     *   Error < 0.1%, well within UART spec.
     */
    USART2->BRR = (uint32_t)(SYSCLK_HZ / BAUD_RATE);

    /* Step 2: 1 stop bit (default), no parity (default), 8 data bits (default) */
    USART2->CR2 &= ~USART_CR2_STOP;    /* STOP[1:0] = 00 = 1 stop bit */

    /* Step 3: Enable transmitter, receiver, and USART */
    USART2->CR1 = USART_CR1_TE    /* Transmitter enable */
                | USART_CR1_RE    /* Receiver enable     */
                | USART_CR1_UE;   /* USART enable        */
}

/**
 * systick_init()
 * Configure Cortex-M4 SysTick for 1 ms interrupts (g_ms_ticks timebase).
 *
 * SysTick is a 24-bit down-counter built into the Cortex-M4 core.
 *
 * Registers:
 *   SysTick->LOAD  – Reload value.  Counter reloads this value after reaching 0.
 *                    For 1 ms tick: LOAD = (SYSCLK / 1000) - 1
 *                                        = (16,000,000 / 1000) - 1 = 15,999
 *
 *   SysTick->VAL   – Current counter value.  Write any value to clear it.
 *
 *   SysTick->CTRL  – Control and Status Register.
 *                    Bit 2 (CLKSOURCE) = 1 -> use processor (AHB) clock.
 *                    Bit 1 (TICKINT)   = 1 -> assert SysTick exception on 0.
 *                    Bit 0 (ENABLE)    = 1 -> enable the counter.
 *
 * CMSIS provides the SysTick_Config() helper which sets all three for us.
 */
static void systick_init(void)
{
    /*
     * SysTick_Config(ticks) sets LOAD = ticks-1, clears VAL, sets CTRL.
     * Returns 0 on success, 1 if ticks exceeds 24-bit maximum (0xFFFFFF).
     * SYSCLK_HZ/1000 = 16000, which is << 16,777,215, so no overflow.
     */
    SysTick_Config(SYSCLK_HZ / 1000U);   /* 1 ms period */

    /*
     * SysTick priority should be higher (lower number) than TIM2 so the
     * millisecond counter stays accurate even when TIM2 ISR is running.
     * SysTick_Config sets priority to (1<<__NVIC_PRIO_BITS) - 1 (lowest).
     * We explicitly raise it here.
     */
    NVIC_SetPriority(SysTick_IRQn, 0);   /* Highest user priority */
}

/* ============================================================================
 * UTILITY FUNCTIONS
 * ============================================================================ */

/**
 * millis()
 * Returns the number of milliseconds elapsed since startup.
 * Reads g_ms_ticks atomically (32-bit read on ARM is atomic).
 */
static uint32_t millis(void)
{
    return g_ms_ticks;
}

/**
 * led_set()
 * Drive PA5 HIGH (LED ON) or LOW (LED OFF).
 *
 * Uses BSRR (Bit Set/Reset Register) for atomic writes:
 *   Bits [15:0]  = Set   bits: writing 1 sets the corresponding ODR bit.
 *   Bits [31:16] = Reset bits: writing 1 clears the corresponding ODR bit.
 * This avoids read-modify-write race conditions present with ODR |= / &=.
 *
 * @param state  1 = LED ON, 0 = LED OFF
 */
static void led_set(uint8_t state)
{
    if (state)
    {
        /* Set PA5: write 1 to BSRR bit 5 (SET section) */
        GPIOA->BSRR = (1U << 5);
    }
    else
    {
        /* Reset PA5: write 1 to BSRR bit 21 (RESET section = bit 5 + 16) */
        GPIOA->BSRR = (1U << (5 + 16));
    }
}

/**
 * uart_send_string()
 * Blocking transmit of a null-terminated string over USART2.
 *
 * Polls TXE (Transmit Data Register Empty) flag in SR before each byte.
 * Suitable for debug output; for production use DMA or interrupt-driven TX.
 *
 * @param str  Null-terminated C string to send.
 */
static void uart_send_string(const char *str)
{
    while (*str)
    {
        /*
         * Wait until TXE = 1 (DR is empty and ready to accept a new byte).
         * USART_SR_TXE is bit 7 of the Status Register.
         */
        while (!(USART2->SR & USART_SR_TXE))
        {
            /* busy-wait */
        }

        /*
         * Write the next character to the Data Register.
         * This clears TXE and starts transmission of the byte.
         * The shift register will move the byte out at the baud rate.
         */
        USART2->DR = (uint8_t)(*str++);
    }
}

/* ============================================================================
 * END OF FILE
 * ============================================================================
 *
 * PORTING NOTES:
 * --------------
 * 1. Different HSI/PLL frequency?
 *    Update SYSCLK_HZ and recalculate TIM2_PSC, TIM2_ARR, BRR.
 *    Formula: PSC*ARR = SYSCLK / desired_freq - 1 (pick PSC & ARR to fit in registers).
 *
 * 2. Different LED/Button pins?
 *    Change the MODER/PUPDR/AFR setup in gpio_init() and the
 *    GPIOX->BSRR / GPIOX->IDR references in led_set() and main().
 *
 * 3. Want true 1 Hz blink (50% duty)?
 *    Change TIM2_ARR to 499 (TIM2 fires at 2 Hz, toggle rate = 2 Hz,
 *    LED completes one on+off cycle per second).
 *
 * 4. Compile (bare-metal, no HAL):
 *    arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfpu=fpv4-sp-d16 \
 *      -mfloat-abi=hard -O2 -Wall \
 *      -DSTM32F401xE \
 *      -I /path/to/CMSIS/Include \
 *      -I /path/to/STM32F4xx/Include \
 *      stm32f4_led_button.c startup_stm32f401xe.s \
 *      -T STM32F401RETx_FLASH.ld -o firmware.elf
 *
 * ============================================================================
 */
